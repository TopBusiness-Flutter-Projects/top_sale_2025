import 'package:flutter/material.dart';

double getSize(BuildContext context) {
  return MediaQuery.of(context).size.width;
}
double getheightSize(BuildContext context) {
  return MediaQuery.of(context).size.height;
}
