abstract class BasketState {}

class InitBasketState extends BasketState {}
