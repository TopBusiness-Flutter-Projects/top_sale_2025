abstract class ContactUsState {}

class ContactUsInitial extends ContactUsState {}
