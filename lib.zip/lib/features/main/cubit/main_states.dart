abstract class MainStates {}

class MainInitialState extends MainStates {}

class AppNavBarChangeState extends MainStates {}
