abstract class OnboardingState {}

class OnboardingInitial extends OnboardingState {}

class OnBoardingInitial extends OnboardingState {}

class ChangingPagesState extends OnboardingState {}
