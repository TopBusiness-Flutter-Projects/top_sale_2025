class ReturnsState {}

 class ReturnsInitial extends ReturnsState {}
 class GetReturnedLoadedState extends ReturnsState {}
 class GetReturnedErrorState extends ReturnsState {}
 class GetReturnedLoadingState extends ReturnsState {}
