abstract class SplashState {}

class SplashInitial extends SplashState {}
